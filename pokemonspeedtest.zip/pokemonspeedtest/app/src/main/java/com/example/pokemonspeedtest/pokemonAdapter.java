package com.example.pokemonspeedtest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class pokemonAdapter extends RecyclerView.Adapter {

    ArrayList<pokemon> pArray ;
    Context context;

    public pokemonAdapter(ArrayList<pokemon> pArray, Context context) {
        this.pArray =pArray;
        this.context =context;

    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout,parent,false);
        Viewholder vh =new Viewholder((v));
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((Viewholder)holder).ing.setImageResource(pArray.get(position).getImage());
        ((Viewholder)holder).total.setText(pArray.get(position).getTotal()+"");
        ((Viewholder)holder).name.setText(pArray.get(position).getName());

    }

    @Override
    public int getItemCount() {
        return pArray.size();
    }

public static class Viewholder extends RecyclerView.ViewHolder {
        public ImageView ing;
        public TextView name;
        public TextView total;
        public View view;
    public Viewholder(@NonNull View itemView) {
        super(itemView);
        view = itemView ;
        ing = itemView.findViewById(R.id.imageView2);
        name =itemView.findViewById(R.id.name);
       total =itemView.findViewById(R.id.total2);

    }
}
}
