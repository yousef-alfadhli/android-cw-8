package com.example.pokemonspeedtest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.icu.util.RangeValueIterator;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        ArrayList<pokemon>   pokeball =new ArrayList<>();


       pokemon p1 =new pokemon("arbok",R.drawable.arbok,95,69,164);
       pokemon p2 =new pokemon("Bulbasaur",R.drawable.eevee,49,49,98);
       pokemon p3 =new pokemon("eevee",R.drawable.bulbasaur,55,50,105);
       pokemon p4 =new pokemon("Rayquaza",R.drawable.rayquaza,150,90,164);
       pokemon p5 =new pokemon("Charizard",R.drawable.charizard,100,120,164);
        pokemon p6 =new pokemon("arbok",R.drawable.arbok,95,69,164);
        pokemon p7 =new pokemon("Bulbasaur",R.drawable.eevee,49,49,98);
        pokemon p8 =new pokemon("eevee",R.drawable.bulbasaur,55,50,105);
        pokemon p9 =new pokemon("Rayquaza",R.drawable.rayquaza,150,90,164);
        pokemon p10 =new pokemon("Charizard",R.drawable.charizard,100,120,164);

       pokeball.add(p1);
        pokeball.add(p2);
        pokeball.add(p3);
        pokeball.add(p4);
        pokeball.add(p5);
        pokeball.add(p6);
        pokeball.add(p7);
        pokeball.add(p8);
        pokeball.add(p9);
        pokeball.add(p10);

        RecyclerView RV =findViewById(R.id.recycle);
        RV.setHasFixedSize(true);
        RecyclerView.LayoutManager im = new LinearLayoutManager(this);
        RV.setLayoutManager(im);

        pokemonAdapter pa = new pokemonAdapter(pokeball,this);
        RV.setAdapter(pa);







    }
}